print('Hello world!')
print('What is your name?') # Ask for name
myName = input()
print('It is good to meet you, ' + myName)
print(len(myName))
print('What is your age?')
myAge = input()
print('You will be ' + str(int(myAge) + 1) + ' in a year.')
